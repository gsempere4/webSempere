<?php 
  //Seguimos la sesion
  session_start();
  // Verificar si hay una sesión iniciada
  if(isset($_SESSION['usuario'])) {
  // Si hay una sesión iniciada, la destruye
  session_destroy(); 
}
?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Añadimos el Favicon de nuesta empresa -->
    <link rel="icon" type="image/x-icon" href="media/favicon.ico">
    <title>Web Sempere</title>
    <!-- CSS Boostrap -->
    <!--<link rel="stylesheet" href="css/estilos.css">-->
    <link href="css/bootstrap.css" rel="stylesheet">
  </head>
  <body>
    <!--barra de navegació amb navbar i Bootstrap-->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <div class="container">    
        <a class="navbar-brand" href="php/incidencias.php">
          <img src="media/logoweb.png" width="230" height="90" class="d-inline-block align-top" alt="">            
        </a>
        <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
          <a class="navbar-brand" href="php/incidencias.php">Incidencias</a>
          <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
            <li class="nav-item active">
              <a class="nav-link" href="#">Registrar Incidencia</a>
            </li>
          </ul>
          <!-- Desplegable -->
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <?php echo $imagen; ?>
              Perfil
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <li><a class="dropdown-item" href="php/perfil.php">Ver perfil</a></li>
              <li><a class="dropdown-item" href="php/actualizarPerfil.php">Actualizar perfil</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="php/cerrarSession.php">Cerrar sesión</a></li>
            </ul>
          </li>
        </div>    
      </div>  
    </nav>
    <!-- Cos de la pagina-->
    <br> <br>
    <div class="container text-center">
    <!-- fila 1-->
      <div class="row">
        <div class="col-12 m-2 titulo bg-dark text-white"><h2>Login</h2></div> <br>
      </div>
    <!-- fila 2-->
      <div class="row justify-content-center">        
        <div class="col-4"> 
          <!--Contendio Pagina-->
          <main class="form-signin">
            <form action="php/procesarLogin.php" method="post">
              <img class="mb-3" src="media/imagenesPerfiles/porDefecto.png" alt="" width="100" height="100">
              <div class="form-floating">
                <input type="text" class="form-control" id="floatingInput" name="login" required>
                <label for="floatingInput">Usuario</label>
              </div>
              <div class="form-floating">
                <input type="password" class="form-control" id="floatingPassword" name="contrasenya" required>
                <label for="floatingPassword">Contrasenya</label>
              </div>
              <div class="checkbox mb-3">
                <label>
                  <input type="checkbox" value="remember-me"> Remember me
                </label>
              </div>
              <button class="w-100 btn btn-lg btn-primary" type="submit">Sign in</button>
              <p class="mt-2 mb-3 text-muted">Recuperar Contrasenya</p>
              <p class="mt-3 mb-3 text-muted">&copy; 2023–2024</p>
            </form>
          </main>
        </div>       
      </div>
    </div>
    <!-- JS Boostrap -->
    <script src="js/bootstrap.bundle.js"></script>
  </body>
</html>

