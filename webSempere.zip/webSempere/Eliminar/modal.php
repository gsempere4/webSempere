<?php 
//Seguimos la session
    session_start();
    $nombre=$_SESSION["usuario"];

    include("../datos.php");
    include("../funciones.php");

    // Llamamos a la funcion que nos listara las incidencias
    if ($conexion=conectarBDA($host,$user,$pass,$bd,$port)){
      #$imagen=DatosUsuarioPerfil($conexion,$nombre);
      $imagen=imagenPerfil($conexion,$nombre);
      $datos=DatosPersonales($conexion,$nombre);
      mysqli_close($conexion);
    };
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Intranet - Incidencias</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-5">
    <table class="table">
        <thead>
            <tr>
                <th>Última Modificación</th>
                <th>Usuario</th>
                <th>Estado</th>
                <th>Descripción</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <!-- Aquí se generan dinámicamente las filas de la tabla con datos de PHP -->
            <tr>
                <td>2024-02-08</td>
                <td>Juan</td>
                <td>Pendiente</td>
                <td>Incidencia en el servidor</td>
                <td><button class="btn btn-primary" data-toggle="modal" data-target="#myModal">Modificar Estado</button></td>
            </tr>
            <!-- Otras filas de incidencias se agregarían aquí -->
        </tbody>
    </table>
</div>

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Modificar Estado de Incidencia</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="actualizar.php" method="get">
                    <div class="form-group">
                        <label for="estadoSelect">Nuevo Estado:</label>
                        <select class="form-control" id="estadoSelect">
                            <option value="pendiente">Pendiente</option>
                            <option value="en Proceso">En Proceso</option>
                            <option value="resuelto">Resuelto</option>
                        </select>
                        <input type="hidden" name="id_incidencia" value='1'>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                <button type="button" class="btn btn-primary" onclick="updateStatus()">Guardar Cambios</button>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

