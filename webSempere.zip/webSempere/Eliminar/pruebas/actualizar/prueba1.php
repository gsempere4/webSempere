<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Listado de Registros</title>
    <!-- Bootstrap CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- Bootstrap JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

</head>
<body>

<div class="container mt-5">
    <h2>Listado de Registros</h2>
    <table class="table">
        <thead>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Edad</th>
            <th>Actualizar</th>
        </tr>
        </thead>
        <tbody>
        <?php
        // Conexión a la base de datos
        $servername = "localhost";
        $username = "root";
        $password = "Sempere4";
        $database = "ejemplo_php";

        $conn = new mysqli($servername, $username, $password, $database);

        // Verificar la conexión
        if ($conn->connect_error) {
            die("Error en la conexión: " . $conn->connect_error);
        }

        // Obtener los registros de la tabla
        $sql = "SELECT id, nombre, apellido, edad FROM registros";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>".$row["id"]."</td>
                        <td>".$row["nombre"]."</td>
                        <td>".$row["apellido"]."</td>
                        <td>".$row["edad"]."</td>
                        <td><button class='btn btn-primary' data-toggle='modal' data-target='#modalUpdate".$row["id"]."'>Actualizar</button></td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='5'>No se encontraron registros</td></tr>";
        }

        // Cerrar la conexión
        $conn->close();
        ?>
        </tbody>
    </table>
</div>

<?php
// Volver a conectarse a la base de datos
$conn = new mysqli($servername, $username, $password, $database);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error en la conexión: " . $conn->connect_error);
}

// Obtener los registros de la tabla para el modal
$sql = "SELECT id, nombre, apellido, edad FROM registros";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<!-- Modal de Bootstrap -->
                <div class='modal fade' id='modalUpdate".$row["id"]."'>
                    <div class='modal-dialog'>
                        <div class='modal-content'>
                            <!-- Contenido del modal -->
                            <div class='modal-header'>
                                <h4 class='modal-title'>Actualizar Edad</h4>
                                <button type='button' class='close' data-dismiss='modal'>&times;</button>
                            </div>
                            <div class='modal-body'>
                                <form action='actualizar_edad.php' method='POST'>
                                    <input type='hidden' name='id' value='".$row["id"]."'>
                                    <label for='edad'>Nueva Edad:</label>
                                    <input type='number' name='edad' id='edad' required>
                                    <button type='submit' class='btn btn-primary'>Actualizar</button>
                                </form>
                            </div>
                            <div class='modal-footer'>
                                <button type='button' class='btn btn-secondary' data-dismiss='modal'>Cerrar</button>
                            </div>
                        </div>
                    </div>
                </div>";
    }
}

// Cerrar la conexión
$conn->close();
?>

<!-- Bootstrap JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
