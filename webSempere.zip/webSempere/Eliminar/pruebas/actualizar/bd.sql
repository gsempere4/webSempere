CREATE DATABASE IF NOT EXISTS ejemplo_php;
USE ejemplo_php;
CREATE TABLE IF NOT EXISTS registros (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50),
    apellido VARCHAR(50),
    edad INT
);

INSERT INTO registros (nombre, apellido, edad) VALUES ('Juan', 'Pérez', 30);
INSERT INTO registros (nombre, apellido, edad) VALUES ('María', 'Gómez', 25);
INSERT INTO registros (nombre, apellido, edad) VALUES ('Pedro', 'López', 40);
