<?php
// Verifica si se han enviado datos desde el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recupera los datos del formulario
    $nombre = $_POST["nombre"];
    $apellidos = $_POST["apellidos"];
    $direccion = $_POST["direccion"];
    $fecha_nac = $_POST["fecha_nac"];
    $email = $_POST["email"];

    // Procesa la carga de la imagen
    $imagen_nombre = $_FILES["imagen"]["name"];
    $imagen_temporal = $_FILES["imagen"]["tmp_name"];
    $imagen_ruta = "uploads/" . $imagen_nombre; // Ruta donde se guardará la imagen

    // Mueve la imagen cargada a la ruta de destino
    move_uploaded_file($imagen_temporal, $imagen_ruta);

    // Guarda la URL de la imagen en la base de datos
    $imagen_url = "http://localhost/media/$imagen_ruta"; // Reemplaza "tu_directorio" por el directorio donde se encuentra tu script PHP
    $conexion = new mysqli("localhost", "root", "Sempere4", "websempere");
    $sql = "INSERT INTO usuarios (nombre, apellidos, direccion, fecha_nac, email, imagen) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("ssssss", $nombre, $apellidos, $direccion, $fecha_nac, $email, $imagen_url);
    $stmt->execute();
    $stmt->close();
    $conexion->close();

    echo "<h2>¡Datos y imagen guardados correctamente!</h2>";
} else {
    echo "<h2>Error: Acceso no permitido.</h2>";
}
?>

