<?php 
  //Seguimos la session
  session_start();
  // Comprobamos si hay alguna sesion iniciada
  if(!(isset($_SESSION['id']) && isset($_SESSION['usuario']) && isset($_SESSION['contrasenya']))) {
    // Si no hay sesión iniciada, nos redirige a la página de login
    header("Location: ../index.php");
  }else {
    $nombre=$_SESSION["usuario"];
    include("../datos.php");
    include("../funciones.php");
    // Llamamos a la funcion que nos listara las incidencias
    if ($conexion=conectarBDA($host,$user,$pass,$bd,$port)){
      $imagen=imagenPerfil($conexion,$nombre);
      $codigo=categorias($conexion);
      $administracion=administracionUsuarios();
      mysqli_close($conexion);
    };
  };
?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Añadimos el Favicon de nuesta empresa -->
    <link rel="icon" type="image/x-icon" href="../media/favicon.ico">
    <title>Web Sempere</title>
    <!-- CSS Boostrap -->
    <!--<link rel="stylesheet" href="css/estilos.css">-->
    <link href="../css/bootstrap.css" rel="stylesheet">
  </head>
  <body>
    <!--barra de navegació amb navbar i Bootstrap-->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <div class="container">    
        <a class="navbar-brand" href="incidencias.php">
          <img src="../media/logoweb.png" width="230" height="90" class="d-inline-block align-top" alt="">            
        </a>
        <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
          <a class="navbar-brand" href="incidencias.php">Incidencias</a>
          <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
            <li class="nav-item active">
              <a class="nav-link" href="registrarIncidencia.php">Registrar Incidencia</a>
            </li>
            <?php print $administracion ?> 
          </ul>
          <?php echo $imagen; ?>
          <!-- Desplegable -->
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <?php print $nombre; ?>
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <li><a class="dropdown-item" href="perfil.php">Ver perfil</a></li>
              <li><a class="dropdown-item" href="actualizarPerfil.php">Actualizar perfil</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="cerrarSession.php">Cerrar sesión</a></li>
            </ul>
          </li>
        </div>
      </div>  
    </nav>
    <!-- Cos de la pagina-->
    <br> <br>
    <div class="container text-center">
      <!-- fila 1-->
      <div class="row">
      <div class="col-12 m-2 titulo bg-dark text-white"><h2>Registrar Incidencia</h2></div> <br>
      </div>
      <!-- fila 2-->
      <div class="row justify-content-center">
        <div class="col-4"> 
          <!--Contendio Pagina-->
          <form action="procesarRegistrarIncidencia.php" method="POST">              
            <div class="mb-3">
              <label for="" class="form-label">Categoria</label>
              <select id="" class="form-select" name="categoria">
                <?php echo $codigo; ?>
              </select>
            </div>
            <div class="mb-3">
              <label for="" class="form-label">Estado de la incidencia</label>
              <select name="estado" id="" class="form-select">
                <option value="pendiente" selected>Pendiente</option>
                <option value="en revision">En Revision</option>
                <option value="cerrada">Cerrada</option>
              </select>
            </div>
            <div class="mb-3">
              <textarea class="form-control" id="" name="descripcion" required placeholder="Describe tu incidencia aqui..."></textarea>                
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
          </form>
        </div>
      </div>
    </div>
    <!-- JS Boostrap -->
    <script src="../js/bootstrap.bundle.js"></script>
  </body>
</html>