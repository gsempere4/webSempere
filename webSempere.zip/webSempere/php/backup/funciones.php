<?php
//Incluimos el contenido del archivo "datos.php"
include("datos.php");

// Establecer conexion con la base de datos
function conectarBDA($host,$user,$pass,$bd,$port){
    $conexion=mysqli_connect($host,$user,$pass,$bd,$port);
    if (!$conexion){
        return false;
    }else {
        return $conexion;
    }
}
// Insertar una nueva incidencia
function insertarIncidencia($conexion,$usuario,$categoria,$descripcion,$estado){
    $consulta="INSERT INTO incidencias VALUES (NULL, NULL, $usuario, $categoria, $descripcion, $estado)";
}
// Desplegable de categorias existentes en la base de datos
function categorias($conexion){
    $consulta="SELECT * FROM categorias";
    $filas=mysqli_query($conexion,$consulta);
        while ($fila=mysqli_fetch_array($filas)){
            $id_categoria=$fila["id_categoria"];
            $nombre=$fila["nombre"];
            $codigo .= '<option value="' . $id_categoria. '">'. $nombre . '</option>';
        }
    return $codigo;
}
// Listado de incidencias mostrado en una tabla
function incidencias($conexion){
    $consulta="SELECT * FROM incidencias";
    $filas=mysqli_query($conexion,$consulta);
    $codigo = "<table class='table table-striped table-bordered'>";
        $codigo .= "<tr>";
            $codigo .= "<th>Fecha Registro</th>";
            $codigo .= "<th>Usuario</th>";
            $codigo .= "<th>Categoria</th>";
            $codigo .= "<th>Descripcion</th>";
            $codigo .= "<th>Estado</th>";
            $codigo .= "<th>Operacion</th>";               
        $codigo .= "</tr>";
       
    while ($fila=mysqli_fetch_array($filas)){
        $id=$fila["id_incidencia"];
        $fecha=$fila["fecha"];
        $usuario=$fila["usuario"];
        $categoria=$fila["categoria"];
        $descripcion=$fila["descripcion"];
        $estado=$fila["estado"];
        
        $codigo .= "<tr>";
            $codigo .= '<td>' . $fecha . '</td>';
            $codigo .= '<td>' . $usuario . '</td>';
            $codigo .= '<td>' . $categoria . '</td>';
            $codigo .= '<td>' . $descripcion . '</td>';
            switch ($estado){
                case "pendiente":
                    //code block
                    $codigo .= '<td class="bg-danger text-white">' . $estado . '</td>';
                    break;
                case "en revision":
                    //code block;
                    $codigo .= '<td class="bg-warning text-dark">' . $estado . '</td>';
                    break;
                case "cerrada":
                    //code block
                    $codigo .= '<td class="bg-success text-white">' . $estado . '</td>';
                    break;
                }
            // Boton para actualizar esta incidencia pasando el id de esta
            $codigo .= '<td>'.'<a href="actualizar.php?id='. $id . '">Actualizar</a>' . '</td>';
    }            
        $codigo .= "</tr>";
    $codigo .= "</table>";
    return $codigo; 
}
// Comprobacion del formulario del login
function login($conexion,$usuario,$contrasenya){
    $consulta="SELECT * FROM creedenciales WHERE usuario='$usuario' AND contrasenya='$contrasenya'";
    $datos=mysqli_query($conexion,$consulta);
    $fila=mysqli_num_rows($datos);
    if ($datos && $fila==1){
        // Creamos una session con el nombre de usuario loggeado en esta sesion con contrasenya i id
        session_start();
        $_SESSION["id"]=$id_login;
        $_SESSION["usuario"]=$usuario;
        $_SESSION["contrasenya"]=$contrasenya;
        header("Location: incidencias.php"); // Si el login es correcto nos redireccionara a la pagina de inicio
        exit(); 
    }else {
        print "El usuario no se encuentra en el sistema";
        header("Location: ../index.php");
    }
}
function categoria($conexion,$id_categoria){
    $consulta="SELECT nombre FROM categorias WHERE id_categoria='$id_categoria'";
    $datos=mysqli_query($conexion,$consulta);
    while ($dato=mysqli_fetch_array($datos)){
        $categoria=$dato["nombre"];
        return $categoria;
    }
}
function datosIncidencia($conexion,$id){
    $consulta="SELECT * FROM incidencias WHERE id_incidencia='$id'";
    $datos=mysqli_query($conexion,$consulta);
    while ($dato=mysqli_fetch_array($datos)){
        $id=$dato["id_incidencia"];
        $id_categoria=$dato["categoria"];
        $descripcion=$dato["descripcion"];
        $estado=$dato["estado"];
        // Saber el nombre de la categoria
        $categoria=categoria($conexion,$id_categoria);
    }
}

/*
function actualitzarcontrasenya($conexion, $contrasenya, $id_login) {
    $consulta="UPDATE credenciales SET contrasenya='$contrasenya' WHERE id_login = '$id_login'";
    if(mysqli_query($conexion,$consulta)===TRUE){
       print "Contrasenya actualizada con exito";
   }else{
       print "No s'ha pogut actualizar la contrasenya";
   }
}
*/
?>