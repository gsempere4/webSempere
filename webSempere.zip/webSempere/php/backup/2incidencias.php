<?php 
//Seguimos la session
    session_start();
?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Sempere</title>
    <!-- CSS Boostrap -->
    <!--<link rel="stylesheet" href="css/estilos.css">-->
    <link href="../css/bootstrap.css" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>
    <!--barra de navegació amb navbar i Bootstrap-->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <div class="container">    
        <a class="navbar-brand" href="incidencias.php">
          <img src="../media/logoweb.png" width="230" height="90" class="d-inline-block align-top" alt="">            
        </a>      
        <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
          <a class="navbar-brand" href="incidencias.php">Incidencias</a>
          <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
            <li class="nav-item active">
              <a class="nav-link" href="registrar_incidencia.php">Registrar Incidencia</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="../index.php">Login</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="cerrar_session.php" tabindex="-1" aria-disabled="true">Cerrar Session</a>
            </li>
          </ul>    
        </div>
      </div>  
    </nav>
    <!-- Cos de la pagina-->
    <br> <br>
    <div class="container text-center">
      <!-- fila 1-->
      <div class="row">
        <div class="col-12 m-2 titulo bg-dark text-white"><h2>Incidencias</h2></div> <br>
      </div>
    <!-- fila 2-->
      <div class="row">
        <div class="col-12"> 
          <!--Contendio Pagina-->
          <?php
            include("../datos.php");
            include("../funciones.php");
            // Llamamos a la funcion que nos listara las incidencias
            if ($conexion=conectarBDA($host,$user,$pass,$bd,$port)){
                $listar=incidencias($conexion);
                // Pintamos lo dado por la variable
                print $listar;
                //Cerramos la conexion
                mysqli_close($conexion); 
            };
          ?>

          <!-- Modal -->
          <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                  <div class="modal-content">
                      <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel">Modificar Estado de Incidencia</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                          </button>
                      </div>
                      <div class="modal-body">
                      <form method="post" action="procesar_formulario.php">
                        <div class="form-group">
                          <label for="estadoSelect">Nuevo Estado:</label>
                          <select class="form-control" id="estadoSelect" name="estado">
                            <option value="Pendiente">Pendiente</option>
                            <option value="En Proceso">En Proceso</option>
                            <option value="Resuelto">Resuelto</option>
                          </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                      </form>

                      </div>
                      <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                          <button type="button" class="btn btn-primary" onclick="updateStatus()">Guardar Cambios</button>
                      </div>
                  </div>
              </div>
          </div>             
        </div>
      </div>
    </div>
    <!-- JS Boostrap -->
    <!--<script src="../js/script.js"></script>-->
    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.bundle.js"></script>
    <!-- Si no lo pongo con CDN no funciona -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  </body>
</html>