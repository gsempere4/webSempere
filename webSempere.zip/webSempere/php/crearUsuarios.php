<?php 
  //Seguimos la session
  session_start();
  // Comprobamos si hay alguna sesion iniciada
  if(!(isset($_SESSION['id']) && isset($_SESSION['usuario']) && isset($_SESSION['contrasenya']) && ($_SESSION["rol"])!="trabajador")){
    // Si no hay sesión iniciada, nos redirige a la página de login
    header("Location: ../index.php");
  }
  $nombre=$_SESSION["usuario"];
  include("../datos.php");
  include("../funciones.php");
  // Llamamos a la funcion que nos listara las incidencias
  if ($conexion=conectarBDA($host,$user,$pass,$bd,$port)){    
    $imagen=imagenPerfil($conexion,$nombre);
    $datos=DatosPersonales($conexion,$nombre);
    $administracion=administracionUsuarios();
    $modalRegistrarIncidencia=registrarIncidenciaModal($conexion);
    mysqli_close($conexion);
  };
?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Añadimos el Favicon de nuesta empresa -->
    <link rel="icon" type="image/x-icon" href="../media/favicon.ico">
    <title>Web Sempere</title>
    <!-- CSS Boostrap -->
    <!--<link rel="stylesheet" href="css/estilos.css">-->
    <link href="../css/bootstrap.css" rel="stylesheet">
  </head>
  <body>
    <!--barra de navegació amb navbar i Bootstrap-->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">    
      <a class="navbar-brand" href="incidencias.php">
        <img src="../media/logoweb.png" width="230" height="90" class="d-inline-block align-top" alt="">            
      </a>
      <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
        <a class="navbar-brand" href="incidencias.php">Incidencias</a>
        <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
          <li class="nav-item active">
            <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#modalRegistrarIncidencia">Registrar Incidencia</a>        
          </li>
          <?php print $administracion ?>          
        </ul>
        <?php echo $imagen; ?>
        <!-- Desplegable -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown">              
            <?php print $nombre; ?>
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><a class="dropdown-item" href="perfil.php">Ver perfil</a></li>
            <li><a class="dropdown-item" href="actualizarPerfil.php">Actualizar perfil</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="cerrarSession.php">Cerrar sesión</a></li>
          </ul>
        </li> 
      </div>
    </div>  
  </nav>
    <!-- Cos de la pagina-->
    <br> <br>
    <div class="container justify-content-center">
        <!-- fila 1-->
        <div class="row">
            <div class="col-12 m-2 titulo bg-dark text-white text-center"><h2>Registrar Nuevo Usuario</h2></div>
            <br>            
        </div>
        <?php 
          // Comprobamos si la session esta creada
          if ($_SESSION['mensaje']){
            // mostramos la session mensaje que contendra si ha sido exitosa o erronea la operacion al actualizar la incidencia
            echo $_SESSION['mensaje']; 
            // Una vez se a mostrado se elimina la sesion
            unset($_SESSION['mensaje']);
          }
        ?>
        <!-- fila 2-->
        <div class="row">
            <div class="col-12"> 
            <!--Contendio Pagina-->
            <div class="container">
                <div class="row">
                        <div class="col-12">
                            <!-- Formulario en la parte derecha -->
                            <h2 class="text-center mt-2 bg-info">Nuevo Usuario</h2>
                            <form action="procesarCrearUsuario.php" method="post">
                                <!-- Fila 1 -->
                                <input type="hidden" name="id" value="' . $id_usuario . '">
                                <div class="row mb-3">
                                    <div class="col">
                                        <label for="" class="form-label left-align">Nombre: </label>
                                        <input type="text" name="nombre" class="form-control">
                                    </div>
                                    <div class="col">
                                        <label for="" class="form-label left-align">Apellidos: </label>
                                        <input type="text" name="apellidos" class="form-control">
                                    </div>                            
                                </div>
                                <!-- Fila 2 -->
                                <div class="row mb-3">                    
                                    <div class="col-3">
                                        <label for="" class="form-label left-align">Fecha Nacimiento: </label>
                                        <input type="date" name="fecha_nac" class="form-control">
                                    </div>
                                    <div class="col-9">
                                        <label for="" class="form-label">Direccion:</label>
                                        <input type="text" name="direccion" class="form-control">
                                    </div>                      
                                </div>
                                <!-- Fila 3 -->
                                <div class="row mb-3"> 
                                    <div class="col-4">
                                        <label for="" class="form-label left-align">Cuenta Usuario: </label>
                                        <div class="input-group">
                                            <div class="input-group-text">@</div>
                                            <input type="text" name="cuenta" class="form-control" required>
                                        </div>
                                    </div>
                                    <div class="col-4"> 
                                      <label for="" class="form-label left-align">Contraseña:</label>
                                      <input type="password" class="form-control" name="contrasenya" required placeholder="Ingrese una contraseña para el usuario">
                                    </div>  
                                    <div class="col-4"> 
                                      <label for="" class="form-label left-align">Rol:</label>
                                      <select class="form-control" name="rol">
                                        <option value="trabajador">Trabajador</option>
                                        <option value="admin">Admin</option>                                        
                                      </select>
                                    </div> 
                                </div> 
                                <!-- Fila 4 -->                
                                <div class="row mb-3">
                                    <div class="col">                                                                                 
                                        <label for="" class="form-label">Correo electrónico:</label>
                                        <input type="email" name="email" class="form-control">   
                                    </div> 
                                    <div class="col"> 
                                        <label for="" class="form-label">Imagen de Perfil</label>
                                        <input type="file" name="imagen" class="form-control"> 
                                    </div>                    
                                </div>
                                <!-- Fila 5 -->                            
                                <div class="row mb-3 ">                                    
                                    <div class="col-12 position-relative">                                      
                                        <a href="crearUsuarios.php" class="btn btn-danger top-0 start-0 position-absolute">Cancelar</a>
                                        <input type="submit" class="btn btn-primary top-0 end-0 position-absolute" value="Crear Usuario">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal Insertar Incidencia -->
    <?php
      print "<br><br>";
      echo $modalRegistrarIncidencia;
    ?>
    <!-- Codigo para funcionar el mensaje de bootstrap -->
    <script>
      // Para mostrar el Mensaje de bootstrap
        const alertPlaceholder = document.getElementById('liveAlertPlaceholder')
        const appendAlert = (message, type) => {
        const wrapper = document.createElement('div')
        wrapper.innerHTML = [
          `<div class="alert alert-${type} alert-dismissible" role="alert">`,
          `   <div>${message}</div>`,
          '   <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>',
          '</div>'
        ].join('')

          alertPlaceholder.append(wrapper)
        }

        const alertTrigger = document.getElementById('liveAlertBtn')
        if (alertTrigger) {
          alertTrigger.addEventListener('click', () => {
            appendAlert('Nice, you triggered this alert message!', 'success')
          })
        }
      </script>  
    <!-- JS Boostrap -->
    <script src="../js/bootstrap.bundle.js"></script>
  </body>
</html>