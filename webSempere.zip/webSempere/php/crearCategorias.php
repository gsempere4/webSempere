<?php 
  //Seguimos la session
  session_start();
  // Comprobamos si hay alguna sesion iniciada
  if(!(isset($_SESSION['id']) && isset($_SESSION['usuario']) && isset($_SESSION['contrasenya']) && ($_SESSION["rol"])!="trabajador")) {
    // Si no hay sesión iniciada, nos redirige a la página de login
    header("Location: ../index.php");
  }
  $nombre=$_SESSION["usuario"];
  include("../datos.php");
  include("../funciones.php");
  // Llamamos a la funcion que nos listara las incidencias
  if ($conexion=conectarBDA($host,$user,$pass,$bd,$port)){    
    $imagen=imagenPerfil($conexion,$nombre);
    $datos=DatosPersonales($conexion,$nombre);
    $administracion=administracionUsuarios();
    $modalRegistrarIncidencia=registrarIncidenciaModal($conexion);
    $listaCategorias=listarCategorias($conexion);
    mysqli_close($conexion);
  };
?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Añadimos el Favicon de nuesta empresa -->
    <link rel="icon" type="image/x-icon" href="../media/favicon.ico">
    <title>Web Sempere</title>
    <!-- CSS Boostrap -->
    <!--<link rel="stylesheet" href="css/estilos.css">-->
    <link href="../css/bootstrap.css" rel="stylesheet">
  </head>
  <body>
    <!--barra de navegació amb navbar i Bootstrap-->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">    
      <a class="navbar-brand" href="incidencias.php">
        <img src="../media/logoweb.png" width="230" height="90" class="d-inline-block align-top" alt="">            
      </a>
      <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
        <a class="navbar-brand" href="incidencias.php">Incidencias</a>
        <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
          <li class="nav-item active">
            <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#modalRegistrarIncidencia">Registrar Incidencia</a>        
          </li>
          <?php echo $administracion ?>
        </ul>
        
        <?php echo $imagen; ?>
        <!-- Desplegable -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown">              
            <?php print $nombre; ?>
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><a class="dropdown-item" href="perfil.php">Ver perfil</a></li>
            <li><a class="dropdown-item" href="actualizarPerfil.php">Actualizar perfil</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="cerrarSession.php">Cerrar sesión</a></li>
          </ul>
        </li> 
      </div>
    </div>  
  </nav>
    <!-- Cos de la pagina-->
    <br> <br>
    <div class="container text-center">
        <!-- fila 1-->
        <div class="row">
            <div class="col-12 m-2 titulo bg-dark text-white"><h2>Categorias</h2></div>
            <br>
        </div>
        <!-- fila 2-->
        <div class="row justify-content-center">
            <div class="col-6"> 
            <!--Listado de Categorias-->
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Operacion</th>
                    </tr>
                </thead>
                <tbody>
                    <?php echo $listaCategorias; ?>                  
                </tbody>
                </table>
            </div>
            <div class="col-1 text-right"> </div>
            <div class="col-4 text-right"> 
                <!--Nueva Categorias-->
                <h2 class="text-center mb-4">Nueva Categoria</h2>
                <form action="procesarCrearCategorias.php" method="post">
                    <div class="form-group">
                        <input type="text" class="form-control" name="nombre" placeholder="Nombre de la categoria">
                    </div>
                    <button type="submit" class="m-3 btn btn-primary btn-block">Añadir Categoria</button>
                </form>
            </div>
            <div class="col-2 text-right"> </div>
        </div>
    </div>
    <!-- Modal Insertar Incidencia -->
    <?php
      print "<br><br>";
      echo $modalRegistrarIncidencia;
    ?>
    <!-- JS Boostrap -->
    <script src="../js/bootstrap.bundle.js"></script>
  </body>
</html>