<?php
    session_start();
    include("../datos.php");
    include("../funciones.php");
    //Recogemos los datos del formulario i lo guardamos en variables
    $nombre=$_POST["nombre"];    
    $apellidos=$_POST["apellidos"]; 
    $fecha_nac=$_POST["fecha_nac"]; 
    $direccion=$_POST["direccion"]; 
    $email=$_POST["email"]; 
    //$imagen=$_POST["imagen"];
    $cuenta=$_POST["cuenta"]; 
    $contrasenya=$_POST["contrasenya"]; 
    $rol=$_POST["rol"]; 
    // Creamos la conexion con la db y funcion que añade la categoria a la tabla categorias 
    if ($conexion=conectarBDA($host,$user,$pass,$bd,$port)){      
        if (consultarCreedencial($conexion,$cuenta)){   
            $insertarCreedenciales="INSERT INTO creedenciales VALUES (NULL, '$cuenta', '$contrasenya', '$rol')";           
            if (crearCreedencial($conexion,$insertarCreedenciales)){
                $contrasenyaCifrada=hash("sha256", $contrasenya);
                $idCreedencial="SELECT * FROM creedenciales WHERE usuario='$cuenta' AND contrasenya='$contrasenyaCifrada'";
                $id=consultarId($conexion,$idCreedencial);
                
                // el campo de la fecha da error si esta vacio
                $insertarUsuario="INSERT INTO usuarios (nombre, apellidos, direccion, email, id_login)
                VALUES ('$nombre', '$apellidos', '$direccion', '$email', '$id')"; 
                if (crearUsuario($conexion,$insertarUsuario)){
                    // Mostrar mensaje de actualización
                    $_SESSION['mensaje'] = '<!--Contenido Pagina-->
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        El usuario se ha añadido correctamente
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>';  
                }else{
                    // Mostrar mensaje de actualización
                    $_SESSION['mensaje'] = '<!--Contenido Pagina-->
                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                        Se han añadido las creedenciales pero el usuario no
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>';
                }
            }
        }
        // Cerramos la conexion con la bd
        mysqli_close($conexion);    
    }else {
        // Mostrar mensaje de actualización
        $_SESSION['mensaje'] = '<!--Contenido Pagina-->
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            No se ha podido acceder a la base de datos
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';  
    }
    //volvera a la misma pagina
    header("Location: crearUsuarios.php");
?>