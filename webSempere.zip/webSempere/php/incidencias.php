<?php 
  //Seguimos la session
  session_start();
  // Comprobamos si hay alguna sesion iniciada
  if(!(isset($_SESSION['id']) && isset($_SESSION['usuario']) && isset($_SESSION['contrasenya']))) {
    // Si no hay sesión iniciada, nos redirige a la página de login
    header("Location: ../index.php");
  }else {
    $nombre=$_SESSION["usuario"];
    include("../datos.php");
    include("../funciones.php");
    // Llamamos a la funcion que nos listara las incidencias
    if ($conexion=conectarBDA($host,$user,$pass,$bd,$port)){
      $imagen=imagenPerfil($conexion,$nombre);
      $listar=incidencias($conexion);
      $modal=modalincidencias($conexion);
      rolAdmin($conexion,$nombre);
      $administracion=administracionUsuarios();
      $modalRegistrarIncidencia=registrarIncidenciaModal($conexion);
      mysqli_close($conexion);
    };
  };
?>
<!DOCTYPE html>
<html lang="es">
  <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Añadimos el Favicon de nuesta empresa -->
  <link rel="icon" type="image/x-icon" href="../media/favicon.ico">
  <title>Web Sempere</title>
  <!-- CSS Boostrap -->
  <link rel="stylesheet" href="css/estilos.css">
  <link href="../css/bootstrap.css" rel="stylesheet">
  <script src="../js/jquery-3.5.1.min.js"></script>
  </head>
  <body>
  <!--barra de navegació amb navbar i Bootstrap-->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">    
      <a class="navbar-brand" href="incidencias.php">
        <img src="../media/logoweb.png" width="230" height="90" class="d-inline-block align-top" alt="">            
      </a>
      <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
        <a class="navbar-brand" href="incidencias.php">Incidencias</a>
        <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
          <li class="nav-item active">
            <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#modalRegistrarIncidencia">Registrar Incidencia</a>        
          </li>
          <?php print $administracion ?>          
        </ul>
        <?php echo $imagen; ?>
        <!-- Desplegable -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown">              
            <?php print $nombre; ?>
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><a class="dropdown-item" href="perfil.php">Ver perfil</a></li>
            <li><a class="dropdown-item" href="actualizarPerfil.php">Actualizar perfil</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="cerrarSession.php">Cerrar sesión</a></li>
          </ul>
        </li> 
      </div>
    </div>  
  </nav>
  <!-- Cos de la pagina-->
  
  <!--Contenido Pagina-->

  <br><br>
  <div class="container text-center">
    <!-- fila 1-->
    <div class="row">
      <div class="col-12 m-2 titulo bg-dark text-white"><h2>Incidencias</h2></div>
      <br>
    </div>
    <?php 
      // Comprobamos si la session esta creada
      if ($_SESSION['mensaje']){
        // mostramos la session mensaje que contendra si ha sido exitosa o erronea la operacion al actualizar la incidencia
        echo $_SESSION['mensaje']; 
        // Una vez se a mostrado se elimina la sesion
        unset($_SESSION['mensaje']);
      }
    ?>
    <!-- fila 2-->
    <div class="row">
      <div class="col-12"> 
        <!--Contendio Pagina-->
        <table class='table table-striped table-bordered'>
          <tr>
            <th>Fecha Registro</th>
            <th>Usuario</th>
            <th>Estado</th>
            <th>Descripcion</th>                
            <th>Operacion</th>            
          </tr>
          <!-- Imprimimos el listado de incidencias devuelto por la funcion llamada al principio del archivo -->
          <?php 
            echo $listar; 
          ?>
        </table>            
        <!-- Modal Actualizar -->
        <?php 
          print "<br><br>";
          echo $modal;
        ?>        
      </div>
    </div>
  </div>
  <!-- Modal Insertar Incidencia -->
  <?php
    print "<br><br>";
    echo $modalRegistrarIncidencia;
  ?>
  <!-- Codigo para funcionar el mensaje de bootstrap -->
  <script>
    // Para mostrar el Mensaje de bootstrap
      const alertPlaceholder = document.getElementById('liveAlertPlaceholder')
      const appendAlert = (message, type) => {
      const wrapper = document.createElement('div')
      wrapper.innerHTML = [
        `<div class="alert alert-${type} alert-dismissible" role="alert">`,
        `   <div>${message}</div>`,
        '   <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>',
        '</div>'
      ].join('')

        alertPlaceholder.append(wrapper)
      }

      const alertTrigger = document.getElementById('liveAlertBtn')
      if (alertTrigger) {
        alertTrigger.addEventListener('click', () => {
          appendAlert('Nice, you triggered this alert message!', 'success')
        })
      }
    </script>    
    <!-- Para mostrar u ocultar el mensjae de cierre -->
    <!--
    <script>
      function mostrarMensaje(select) {
          var id = select.id.substring(12); // Obtenemos el ID de la incidencia
          var mensajeCierre = document.getElementById('mensajeCierre' + id);
          if (select.value === 'cerrada') {
              mensajeCierre.style.display = 'block'; // Mostrar el mensaje si se selecciona "cerrada"
          } else {
              mensajeCierre.style.display = 'none'; // Ocultar el mensaje si se selecciona otra opción
          }
      }
    </script>
    -->

  <!-- JS Boostrap -->
  <script src="../js/bootstrap.bundle.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  </body>
</html>