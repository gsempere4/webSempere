<?php 
  //Seguimos la session
  session_start();
  // Comprobamos si hay alguna sesion iniciada
  if(!(isset($_SESSION['id']) && isset($_SESSION['usuario']) && isset($_SESSION['contrasenya']))) {
      // Si no hay sesión iniciada, nos redirige a la página de login
      header("Location: ../index.php");
  }else {
    $nombre=$_SESSION["usuario"];
    include("../datos.php");
    include("../funciones.php");
    // Llamamos a la funcion que nos listara las incidencias
    if ($conexion=conectarBDA($host,$user,$pass,$bd,$port)){
      $imagen=imagenPerfil($conexion,$nombre);
      $datos=DatosPersonales($conexion,$nombre);
      $administracion=administracionUsuarios();
      $modalRegistrarIncidencia=registrarIncidenciaModal($conexion);
      mysqli_close($conexion);
    };
  };
?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Añadimos el Favicon de nuesta empresa -->
    <link rel="icon" type="image/x-icon" href="../media/favicon.ico">
    <title>Web Sempere</title>
    <!-- CSS Boostrap -->
    <!--<link rel="stylesheet" href="css/estilos.css">-->
    <link href="../css/bootstrap.css" rel="stylesheet">
  </head>
  <body>
    <!--barra de navegació amb navbar i Bootstrap-->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <div class="container">    
        <a class="navbar-brand" href="incidencias.php">
          <img src="../media/logoweb.png" width="230" height="90" class="d-inline-block align-top" alt="">            
        </a>
        <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
          <a class="navbar-brand" href="incidencias.php">Incidencias</a>
          <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
          <li class="nav-item active">
            <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#modalRegistrarIncidencia">Registrar Incidencia</a>        
          </li>
            <?php print $administracion ?> 
          </ul>
          <?php echo $imagen; ?>
          <!-- Desplegable -->
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">              
              <?php print $nombre; ?>
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <li><a class="dropdown-item" href="perfil.php">Ver perfil</a></li>
              <li><a class="dropdown-item" href="actualizarPerfil.php">Actualizar perfil</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="cerrarSession.php">Cerrar sesión</a></li>
            </ul>
          </li>
        </div> 
      </div>  
    </nav>
    <!-- Cos de la pagina-->
    <br><br>
    <div class="container">
      <!-- fila 1-->
      <div class="row text-center">
        <div class="col-12 m-2 titulo bg-dark text-white"><h2>Mi Cuenta</h2></div>
        <br>        
      </div>
      <!-- fila 2-->
      <div class="row justify-content-center text-center">
        <div class="col-12">
          <?php 
            // Comprobamos si la session esta creada
            if ($_SESSION['mensaje']){
              // mostramos la session mensaje que contendra si ha sido exitosa o erronea la operacion al actualizar la incidencia
              echo $_SESSION['mensaje']; 
              // Una vez se a mostrado se elimina la sesion
              unset($_SESSION['mensaje']);
            }
          ?>
        </div>
      </div>
      <!-- fila 3-->
      <div class="row">
        <div class="col"> 
          <!--Contendio Pagina-->
          <h2 class="p-2 bg-dark text-info border-bottom text-center">Datos Personales</h2>
          <div class="row">
            <div class="col-12"> 
              <table class="col-12 fs-4">
                  <?php echo $datos; ?>
              </table>               
            </div>
          </div>
        </div>
        <!-- Columna de los datos personales del usuario -->
        <div class="col">
          <h2 class="p-2 p-2 bg-info border-bottom text-center">Acciones</h2>
            <div class="row m-3">
              <div class="d-grid gap-2 col-6 mx-auto">
                <a href="actualizarPerfil.php" class="btn btn-warning ">Actualizar Perfil</a>
              </div>
            </div>            
            <div class="row m-3">
              <div class="d-grid gap-2 col-6 mx-auto">
                <a href="cambiarContrasenya.php" class="btn btn-success">Cambiar Contrasenya</a>
              </div>
            </div>
            <div class="row m-3">
              <div class="d-grid gap-2 col-6 mx-auto">
                <a href="cerrarSession.php" class="btn btn-danger">Cerrar Sesión</a>
              </div>
            </div>                 
          </div>                
        </div>
      </div>
    </div>
    <!-- Modal Insertar Incidencia -->
    <?php
      print "<br><br>";
      echo $modalRegistrarIncidencia;
    ?>
    <!-- Codigo para funcionar el mensaje de bootstrap -->
    <script>
      // Para mostrar el Mensaje de bootstrap
        const alertPlaceholder = document.getElementById('liveAlertPlaceholder')
        const appendAlert = (message, type) => {
        const wrapper = document.createElement('div')
        wrapper.innerHTML = [
          `<div class="alert alert-${type} alert-dismissible" role="alert">`,
          `   <div>${message}</div>`,
          '   <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>',
          '</div>'
        ].join('')

          alertPlaceholder.append(wrapper)
        }

        const alertTrigger = document.getElementById('liveAlertBtn')
        if (alertTrigger) {
          alertTrigger.addEventListener('click', () => {
            appendAlert('Nice, you triggered this alert message!', 'success')
          })
        }
      </script>
    <!-- JS Boostrap -->
    <script src="../js/bootstrap.bundle.js"></script>
  </body>
</html>
