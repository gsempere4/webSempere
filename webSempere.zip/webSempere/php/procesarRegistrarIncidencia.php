<?php 
    session_start();
    include("../datos.php");
    include("../funciones.php");
    //Recogemos los datos del formulario i lo guardamos en variables
    $usuario=$_SESSION["usuario"];
    $categoria=$_POST["categoria"];    
    $descripcion=$_POST["descripcion"];
    $estado=$_POST["estado"];
    // Creamos la conexion con la db y comprobamos mediante funcion si el usuario y contrasenya coincide 
    if ($conexion=conectarBDA($host,$user,$pass,$bd,$port)){    
        insertarIncidencia($conexion,$usuario,$categoria,$descripcion,$estado);        
        header("Location: incidencias.php");
        // Cerramos la conexion con la bd
        mysqli_close($conexion);
    };

?>