<?php
    include("../datos.php");
    include("../funciones.php");
    //Recogemos los datos del formulario i lo guardamos en variables
    $usuario=$_POST["login"];
    $contrasenya=$_POST["contrasenya"];
    // Creamos la conexion con la db y comprobamos mediante funcion si el usuario y contrasenya coincide 
    if ($conexion=conectarBDA($host,$user,$pass,$bd,$port)){    
        login($conexion,$usuario,$contrasenya);
        // Cerramos la conexion con la bd
        mysqli_close($conexion);
    }
?>