<?php
    include("../datos.php");
    include("../funciones.php");
    //Recogemos los datos del formulario i lo guardamos en variables
    $nombreCategoria=$_POST["nombre"];    
    // Creamos la conexion con la db y funcion que añade la categoria a la tabla categorias 
    if ($conexion=conectarBDA($host,$user,$pass,$bd,$port)){    
        nuevaCategoria($conexion,$nombreCategoria);                 
        // Cerramos la conexion con la bd
        mysqli_close($conexion);
        //Una vez se añada la categoria volvera a la misma pagina
        header("Location: crearCategorias.php");

    }
?>