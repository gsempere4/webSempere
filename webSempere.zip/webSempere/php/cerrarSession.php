<?php 
    // Sesguimos la sesión iniciada en las anteriores paginas
    session_start();
    // Eliminamos todas las variables de sesión
    $_SESSION = array();
    // Ahora destruimos la sesión
    session_destroy();
    /*Una vez tenido toda la sesion destruida nos redigira a la 
    página de inicio donde podremos volver a iniciar la sesion con 
    nuestro usuario y contrasenya*/
    header("Location: ../index.php");
?>