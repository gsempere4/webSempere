<?php
    // Verificar si se ha enviado el formulario
    session_start();
    include("../datos.php");
    include("../funciones.php");    
    $nombre=$_SESSION["usuario"];
    // Recogemos los valores del formulario 
    $contrasenyaActual = $_POST['contrasena_actual'];
    $contrasenyaNueva = $_POST['nueva_contrasena'];
    $contrasenyaComprobacion = $_POST['confirmar_contrasena'];

    // Comprobamos que la contrasenya nueva i la confirmada coinciden
    if ($contrasenyaNueva === $contrasenyaComprobacion){
        //Realizamos la comprobacion con la bd + realizamos la primer comprobacion en la bd
        if ($conexion=conectarBDA($host,$user,$pass,$bd,$port)){
            $respuesta=comprobacionContrasenyaActual($conexion,$nombre,$contrasenyaActual);
            // Comprobacion de que el usuario i contrasenya coinciden
            if ($respuesta === TRUE){
                // Pasamos la contrasenya sin cifrar ya que tenemos un trigger que la cifra antes de insertarse en la base de datos
                $consulta="UPDATE creedenciales SET contrasenya='$contrasenyaNueva' WHERE usuario = '$nombre'";
                print $consulta;
                // Comprobamos si se ha actualizado correctamente en la base de datos
                if (actualitzarcontrasenya($conexion,$consulta)===TRUE){
                    // Mostrar mensaje de actualización                    
                    $_SESSION['mensaje'] = '<!--Contenido Pagina-->
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        Se ha actualizado tu contrasenya con exito.
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>';                 
                }else{
                    // Mostrar mensaje de error al cambiar la contrasenya                 
                    $_SESSION['mensaje'] = '<!--Contenido Pagina-->
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        No se ha podido actualizar tu contrasenya en la bd.
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>'; 
                }
            }else{
                // Mostrar mensaje de error al cambiar la contrasenya                 
                $_SESSION['mensaje'] = '<!--Contenido Pagina-->
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    Tu contrasenya no es la correcta.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>'; 
            } 
            mysqli_close($conexion);
        }else{
            // Mostrar mensaje de error al cambiar la contrasenya                 
            $_SESSION['mensaje'] = '<!--Contenido Pagina-->
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                No se ha podido establecer la conexion con la base de datos.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>'; 
        } 
    } else{
        // Mostrar mensaje de error al cambiar la contrasenya                 
        $_SESSION['mensaje'] = '<!--Contenido Pagina-->
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            La nueva contrasenya no coincide en los 2 campos.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';
    }
    header("Location: perfil.php");
?>