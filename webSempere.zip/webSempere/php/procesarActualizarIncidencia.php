<?php
    // Verificar si se ha enviado el formulario
    session_start();
    include("../datos.php");
    include("../funciones.php");
    // Verificar si se recibió el ID del registro y el nuevo estado
    if (isset($_POST["registro_id"]) && isset($_POST["estado"])) {
        // Obtener el ID del registro y el nuevo estado desde el formulario
        $registro_id = $_POST["registro_id"];
        $nuevo_estado = $_POST["estado"];
        // Validar longitud mínima del mensaje
        $mensaje = $_POST['mensaje'];
        if (strlen($mensaje) < 10) {  // strlen() devuelve la longitud de una cadena de texto
            // Mostrar mensaje de actualización
            $_SESSION['mensaje'] = '<!--Contenido Pagina-->
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>ERROR</strong>
                El mensaje / descripcion de la incidencia a actualizar debe tener al menos 10 caracteres.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';            
        }else {
            // Procesar y guardar el mensaje en la base de datos
            // Llamamos a la funcion que nos actualizara el estado de las incidencias
            if ($conexion=conectarBDA($host,$user,$pass,$bd,$port)){
                $consulta="UPDATE incidencias SET estado='$nuevo_estado', descripcion = '$mensaje' WHERE id_incidencia=$registro_id";
                $mensaje=actualizarIncidencia($conexion,$consulta);
                mysqli_close($conexion);
            }; 
            // Mostrar mensaje de actualización
            $_SESSION['mensaje'] = '<!--Contenido Pagina-->
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                Se ha actualizado correctamente la incidencia.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';           
        };
        header("Location: incidencias.php");
    }else{
        echo "Error: ID del registro o nuevo estado no recibidos";
    }
?>