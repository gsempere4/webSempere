<?php
    // Verificar si se ha enviado el formulario
    session_start();
    include("../datos.php");
    include("../funciones.php");    
    #$nombre=$_SESSION["usuario"];
    // Recogemos los valores del formulario 
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $apellidos = $_POST['apellidos'];
    $fecha_nac = $_POST['fecha_nac'];
    $direccion = $_POST['direccion'];
    $cuenta = $_POST['cuenta'];
    $email = $_POST['email'];
    #$urlImagen = $_POST['imagen'];

    // Verificar si se ha enviado una imagen en el formulario    
        $nombreArchivo = $_FILES['imagen']['name'];
        $rutaArchivo = $_FILES['imagen']['tmp_name'];
        $rutaDestino = 'media/imagenesPerfiles/' . $nombreArchivo;
        // Mover la imagen al directorio de destino
        if(move_uploaded_file($rutaArchivo, "../" . $rutaDestino)) {
            // Ahora procedemos a guardar la URL de la imagen para almacenarla en la base de datos
            $urlImagen = 'http://30.40.40.13/' . $rutaDestino;
            
        }
        // Realizamos una parte de la consulta guardandola en una variable
        $consulta="UPDATE usuarios SET nombre='$nombre', apellidos='$apellidos', direccion='$direccion', fecha_nac='$fecha_nac', email='$email'";

        // Agregar la actualización de la imagen solo si se ha cargado una nueva imagen
        if(isset($urlImagen)) {
            $consulta .= ", imagen='$urlImagen'";
        }
        // Por ultimo contatenamos el WHERE a la consulta
        $consulta .= " WHERE id_usuario = '$id'";


    if ($conexion=conectarBDA($host,$user,$pass,$bd,$port)){
        actualizarPerfil($conexion,$consulta);
        header("Location: perfil.php");
        mysqli_close($conexion);
    }; 
?>