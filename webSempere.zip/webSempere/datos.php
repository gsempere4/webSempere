<?php
    // Creedencials de la base de datos

    $host="30.40.40.12"; // IP servidor MySQL
    #$host="localhost"; // IP servidor MySQL

    // Inicia la sesión si no está iniciada
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    // Verifica si la sesión está iniciada y si el rol está vacío
    if (isset($_SESSION['rol']) && empty($_SESSION['rol'])) {
        // Si el rol está vacío, asigna estos valores para logearnos en la base de datos
        $user = "trabajador";
        $pass = "Usuario123";
    } else {
        // Si el rol NO está vacío, asigna estos otros valores para logearnos en la base de datos como ADMINISTRADORES
        $user = "admin";
        $pass = "Sempere4";
    }
    $bd="websempere";
    $port=3306;
?>