<?php
    //Incluimos el contenido del archivo "datos.php"
    include("datos.php");
    // Establecer conexion con la base de datos
    function conectarBDA($host,$user,$pass,$bd,$port){
        $conexion=mysqli_connect($host,$user,$pass,$bd,$port);
        if (!$conexion){
            return false;
        }else {
            return $conexion;
        }
    }
    // Consultar Rol del Usuario
    function rolAdmin($conexion,$usuario){
        $consulta="SELECT rol FROM creedenciales WHERE usuario='$usuario' AND rol='admin'";
        $datos=mysqli_query($conexion,$consulta);
        $filasAfectadas=mysqli_affected_rows($conexion);
        session_start();
        if ($datos AND $filasAfectadas === 1) {
            $user="admin";
            $pass="Sempere4";
            
            $_SESSION["user_bd"]=$user;
            $_SESSION["pass_bd"]=$pass;
        }else{
            $user="trabajador";
            $pass="Usuario123";

            $_SESSION["user_bd"]=$user;
            $_SESSION["pass_bd"]=$pass;
        }
    }
    // Insertar una nueva incidencia
    function insertarIncidencia($conexion,$usuario,$categoria,$descripcion,$estado){
        $consultar_usuario="SELECT id_usuario FROM usuarios WHERE id_login=(SELECT id_login FROM creedenciales WHERE usuario='$usuario')";
        print $consulta;
        $datos=mysqli_query($conexion,$consultar_usuario);
        while ($dato=mysqli_fetch_array($datos)){
            $id_usuario=$dato["id_usuario"];
            print $id_usuario;
        }
        $consulta="INSERT INTO incidencias VALUES (NULL, CURRENT_TIMESTAMP(), '$id_usuario', '$categoria', '$descripcion', '$estado')";
        if (mysqli_query($conexion,$consulta) === TRUE ){
            $mensaje = "Se ha añadido una nueva incidencia";  
        }else {
            $mensaje = "Error al insertar la incidencia";        
        }    
        return $mensaje;
    }
    // Desplegable de categorias existentes en la base de datos
    function categorias($conexion){
        $consulta="SELECT * FROM categorias";
        $filas=mysqli_query($conexion,$consulta);
        while ($fila=mysqli_fetch_array($filas)){
            $id_categoria=$fila["id_categoria"];
            $nombre=$fila["nombre"];
            $codigo .= '<option value="' . $id_categoria. '">'. $nombre . '</option>';
        }
        return $codigo;
    }
    // NOmbre del usuario
    function nombreUsuario($conexion,$id_login){
        $consulta="SELECT usuario FROM creedenciales WHERE id_login=$id_login";
        $datos=mysqli_query($conexion,$consulta);
        while ($dato=mysqli_fetch_array($datos)){
            $nombre_login=$dato["usuario"];
        }
        return $nombre_login;        
    }
    // Listado de incidencias mostrado en una tabla
    function incidencias($conexion){
        $consulta="SELECT * FROM incidencias";
        $filas=mysqli_query($conexion,$consulta);       
        while ($fila=mysqli_fetch_array($filas)){
            $id=$fila["id_incidencia"];
            $fecha=$fila["fecha"];
            $id_usuario=$fila["usuario"];
            $categoria=$fila["categoria"];
            $descripcion=$fila["descripcion"];
            $estado=$fila["estado"];
            // Recogemos el nombre devuelto al llamar la funcion
            $nombre_usuario=nombreUsuario($conexion,$id_usuario);
            $codigo .= "<tr>";
                $codigo .= '<td>' . $fecha . '</td>';
                $codigo .= '<td>' . $nombre_usuario . '</td>';
                
                // Segun el estado se mostrara con un background-color diferente
                switch ($estado){
                    case "pendiente":
                        $codigo .= '<td class="bg-danger text-white text-center align-middle" style="padding: 0;">' . $estado . '</td>';
                        break;
                    case "en revision":;
                        $codigo .= '<td class="bg-warning text-white text-center align-middle" style="padding: 0;">' . $estado . '</td>';
                        break;
                    case "cerrada":
                        $codigo .= '<td class="bg-success text-white text-center align-middle" style="padding: 0;">' . $estado . '</td>';
                        break;
                }
                $codigo .= '<td>' . $descripcion . '</td>';
                // Boton para actualizar esta incidencia pasando el id de esta "data-id="ID_DE_LA_INCIDENCIA""          
                $codigo .= '<td><a href="#" class="btn btn-primary" data-toggle="modal" data-target="#myModal' . $id . '">Actualizar</a></td>';
            $codigo .= "</tr>";          
        }                
        return $codigo; 
    }
    // Listado modal para actualizar una incidencia
    function modalincidencias($conexion){
        $consulta="SELECT id_incidencia FROM incidencias";
        $filas=mysqli_query($conexion,$consulta);       
        $modal = ''; // Inicializamos la variable $modal fuera del bucle
        while ($fila=mysqli_fetch_array($filas)){
            $id=$fila["id_incidencia"];
            $estadoActual = $fila["estado"];
            $descripcionActual = $fila["descripcion"];
            $modal .= '            
            <!-- Modal -->            
            <div class="modal fade" id="myModal' . $id . '" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Cambiar Estado</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="procesarActualizarIncidencia.php" method="post">
                                <input type="hidden" id="registro_id" name="registro_id" value="'. $id .'">      
                                <div class="form-group">     
                                    <label for="">Nuevo Estado:</label>
                                    <select id="" class="form-control" name="estado">
                                        <option value="pendiente">Pendiente</option>
                                        <option value="en revision">En Revision</option>
                                        <option value="cerrada">Cerrada</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="">Mensaje de cambio de estado</label>
                                    <textarea class="form-control" id="" name="mensaje" rows="3" required></textarea>
                                    <small class="form-text text-muted">Mínimo 10 caracteres.</small>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                                    <button type="submit" class="btn btn-primary m-3">Guardar Cambios</button>       
                                </div>                    
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            ';
        }    
        return $modal;
    }
    // Comprobacion del formulario del login
    function login($conexion,$usuario,$contrasenya){
        // Cifrar la contraseña proporcionada por el usuario
        $contrasenya_cifrada = hash("sha256", $contrasenya); // Cambia "sha256"
        // Realizamos una consulta para saber si hay alguna fila que coincide
        $consulta="SELECT * FROM creedenciales WHERE usuario='$usuario' AND contrasenya='$contrasenya_cifrada'";
        print $consulta;
        $datos=mysqli_query($conexion,$consulta);
        $fila=mysqli_num_rows($datos);
        if ($datos && $fila==1){
            // Creamos una session con el nombre de usuario loggeado en esta sesion con contrasenya i id
            session_start();
            while ($dato=mysqli_fetch_array($datos)){
                $_SESSION['id']=$dato['id_login'];
                $_SESSION['usuario']=$dato['usuario'];
                $_SESSION['contrasenya']=$dato['contrasenya'];
                $_SESSION['rol']=$dato['rol'];
            }
            header("Location: incidencias.php"); // Si el login es correcto nos redireccionara a la pagina de inicio
            exit(); 
        }else {
            header("Location: ../index.php");
        }
    }
    // Si el usuario loggeado en la web tiene rol de administrador le aparecera una pestaña mas en la barra de navegacion
    function administracionUsuarios(){
        if ($_SESSION['rol'] === "admin"){
            $administracion='
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown">              
                    Administracion
                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <li><a class="dropdown-item" href="crearCategorias.php">Categorias</a></li>
                    <li><a class="dropdown-item" href="crearUsuarios.php">Usuarios</a></li>
                    <li><a class="dropdown-item" href="#">Incidencias</a></li>
                </ul>
            </li>';                       
        }  
        return $administracion; 
    }
    // Realiza una consulta pasandole el id de la categoria para saber el nombre de esta
    function categoria($conexion,$id_categoria){
        $consulta="SELECT nombre FROM categorias WHERE id_categoria='$id_categoria'";
        $datos=mysqli_query($conexion,$consulta);
        while ($dato=mysqli_fetch_array($datos)){
            $categoria=$dato["nombre"];
            return $categoria;
        }
    }
    // Recorre todo el registro guardando sus valores en variables y llama a otra funcion para resolver el nombre de la categoria
    function datosIncidencia($conexion,$id){
        $consulta="SELECT * FROM incidencias WHERE id_incidencia='$id'";
        $datos=mysqli_query($conexion,$consulta);
        while ($dato=mysqli_fetch_array($datos)){
            $id=$dato["id_incidencia"];
            $id_categoria=$dato["categoria"];
            $descripcion=$dato["descripcion"];
            $estado=$dato["estado"];
            // Saber el nombre de la categoria
            $categoria=categoria($conexion,$id_categoria);
        }
    }
    // Esta funcion nos devuelve una etiqueta <img> con la imagen del perfil
    function imagenPerfil($conexion,$nombre) {
        //Comprueba si la variable nombre esta vacia de ser asi muestra la imagen porDefecto
        if ($nombre == "") {
            $imagen = '<img src="media/imagenesPerfiles/porDefecto.png" alt="Imagen de usuario" width="70">';
        } else {
            // Extrae la URL de la imagen de perfil de ese usuario
            $consulta = "SELECT imagen FROM usuarios WHERE id_login=(SELECT id_login FROM creedenciales WHERE usuario='$nombre')";
            $datosPersonales = mysqli_query($conexion, $consulta);
            $dato = mysqli_fetch_array($datosPersonales);
            // Si hay un valor en la columna imagen de ese usuario la imprime por pantalla la imagen
            if ($dato) {
                $imagen = '<img src="' . $dato["imagen"] . '" alt="Imagen de usuario" width="70">';
            } else {
                // Si no hay nada en esa columna se muestra la imagen por defecto
                $imagen = '<img src="media/imagenesPerfiles/porDefecto.png" alt="Imagen de usuario" width="70">';
            }
        }
        return $imagen;
    }
    // Esta funcion lista todos los datos personales organizandolos en una tabla para luego mostrarla en el perfil
    function DatosPersonales($conexion,$nombre){
        $consulta="SELECT * FROM usuarios WHERE id_login=(SELECT id_login FROM creedenciales WHERE usuario='$nombre')";
        $datosPersonales=mysqli_query($conexion,$consulta);
        while ($dato=mysqli_fetch_array($datosPersonales)){            
            $id_usuario = $dato['id_usuario'];
            $nombreUsuario = $dato['nombre'];
            $apellidos = $dato['apellidos'];
            $direccion = $dato['direccion'];
            $fecha_nac = $dato['fecha_nac'];
            $email = $dato['email'];
            $imagen = $dato['imagen'];
            $id_login = $dato['id_login'];

            $codigo = '
            <tr>                
                <td class="text-center" colspan="4"><img src="' . $dato["imagen"] . '" alt="Imagen de usuario" width="250"></td>
            </tr>
            <tr>
                <th class="text-end">Nombre: </th>
                <td></td>
                <td class="text-start">' . $nombreUsuario . '</td>
            </tr>
            <tr>
                <th class="text-end">Apellidos: </th>
                <td></td>
                <td class="text-start">' . $apellidos . '</td>
            </tr>
            <tr>
                <th class="text-end">Direccion: </th>
                <td></td>
                <td class="text-start">' . $direccion . '</td>
            </tr>
            <tr>
                <th class="text-end">Fecha Nacimiento: </th>
                <td></td>
                <td class="text-start">' . $fecha_nac . '</td>
            </tr>
            <tr>
                <th class="text-end">Email: </th>
                <td></td>
                <td class="text-start">' . $email . '</td>
            </tr>
            ';
        };
        return $codigo;
    }
    // Esta funcion realiza la actualizacion de la incidencia
    function actualizarIncidencia($conexion,$consulta){
        mysqli_query($conexion,$consulta);
        return $consulta;
    }
    // Muestra los datos del usuario los cuales va a poder modificar menos la cuenta ya que no nos interesa cambiar este campo
    // Luego lo procesa el archivo procesarActualizarPerfil.php
    function formularioPerfil($conexion,$nombre){
        $consulta="SELECT * FROM usuarios WHERE id_login=(SELECT id_login FROM creedenciales WHERE usuario='$nombre')";
        $datosPersonales=mysqli_query($conexion,$consulta);
        while ($dato=mysqli_fetch_array($datosPersonales)){            
            $id_usuario = $dato['id_usuario'];
            $nombreUsuario = $dato['nombre'];
            $apellidos = $dato['apellidos'];
            $direccion = $dato['direccion'];
            $fecha_nac = $dato['fecha_nac'];
            $email = $dato['email'];
            $imagen = $dato['imagen'];
            $id_login = $dato['id_login'];

$formulario = ' <div class="container">
                <div class="row">
                    <div class="col-5 d-flex justify-content-center">
                        <!-- Contenido principal -->                    
                            <img class="" src="' . $imagen . '" alt="Imagen de usuario" width="90%">
                        </div>
                        <div class="col-7">
                            <!-- Formulario en la parte derecha -->
                            <h2 class="text-center mt-2">Datos Personales</h2>
                            <form action="procesarActualizarPerfil.php" method="post" enctype="multipart/form-data">
                                <!-- Fila 1 -->
                                <input type="hidden" name="id" value="' . $id_usuario . '">
                                <div class="row mb-3">
                                    <div class="col">
                                        <label for="" class="form-label left-align">Nombre: </label>
                                        <input type="text" name="nombre" class="form-control" value="' . $nombreUsuario . '">
                                    </div>
                                    <div class="col">
                                        <label for="" class="form-label left-align">Apellidos: </label>
                                        <input type="text" name="apellidos" class="form-control" value="' . $apellidos . '">
                                    </div>                            
                                </div>
                                <!-- Fila 2 -->
                                <div class="row mb-3">                    
                                    <div class="col-3">
                                        <label for="" class="form-label left-align">Fecha Nacimiento: </label>
                                        <input type="date" name="fecha_nac" class="form-control" value="' . $fecha_nac . '">
                                    </div>
                                    <div class="col-9">
                                        <label for="" class="form-label">Direccion:</label>
                                        <input type="text" name="direccion" class="form-control" id="" value="'. $direccion . '" >
                                    </div>                      
                                </div>
                                <!-- Fila 3 -->
                                <div class="row mb-3"> 
                                    <div class="col-4">
                                        <label for="" class="form-label left-align">Cuenta Usuario: </label>
                                        <div class="input-group">
                                            <div class="input-group-text">@</div>
                                            <input type="text" name="cuenta" class="form-control" readonly value="' . $nombre . '">
                                        </div> 
                                    </div>  
                                    <div class="col-8">                                            
                                        <label for="" class="form-label">Correo electrónico:</label>
                                        <input type="email" name="email" class="form-control" id="" value="' . $email . '">   
                                    </div>                                             
                                </div>
                                <!-- Fila 4 -->                
                                <div class="row mb-3">
                                    <div class="col">
                                        <label for="" class="form-label">Imagen de Perfil</label>
                                        <input type="file" name="imagen" class="form-control">
                                    </div>                      
                                </div>
                                <!-- Fila 5 -->                            
                                <div class="row mb-3">
                                    <div class="col-7">
                                        <button type="reset" class="btn btn-secondary">Reset</button>
                                    </div>
                                    <div class="col-5">                                      
                                        <a href="perfil.php" class="btn btn-danger">Cancelar</a>
                                        <button type="submit" class="btn btn-primary">Actualizar Datos</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>';
        };
        return $formulario;
    }
    // Esta funcion es la encargada de actualiar los datos añadidos en el formulario en la base de datos
    function actualizarPerfil($conexion,$consulta){
        print $consulta;
        mysqli_query($conexion,$consulta);
    }

    function registrarIncidenciaModal($conexion){
        $registrarIncidencia = '<!-- Modal -->
        <div class="modal fade" id="modalRegistrarIncidencia" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Registrar Incidencia</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Contenido del formulario -->
                <form action="procesarRegistrarIncidencia.php" method="POST">
                <div class="mb-3">
                    <label for="" class="form-label">Categoria</label>
                    <select id="" class="form-select" name="categoria">';
        $registrarIncidencia .=  categorias($conexion);
        $registrarIncidencia .= '</select>
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">Estado de la incidencia</label>
                    <select name="estado" id="" class="form-select">
                    <option value="pendiente" selected>Pendiente</option>
                    <option value="en revision">En Revisión</option>
                    <option value="cerrada">Cerrada</option>
                    </select>
                </div>
                <div class="mb-3">
                    <textarea class="form-control" id="" name="descripcion" required placeholder="Describe tu incidencia aquí..."></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
            </div>
        </div>
        </div>';
        return $registrarIncidencia;
    }
    // Esta funcion comprueba la contrasenya actual del usuario para poder realizar el cambio de contrasenya
    function comprobacionContrasenyaActual($conexion,$nombre,$contrasenyaActual){       
        //ciframos la contrasenya ya que en la base de datos se encuentran cifradas
        $contrasenya_cifrada = hash("sha256", $contrasenyaActual);
        $consultarContrasenyaAntigua="SELECT * FROM creedenciales WHERE usuario='$nombre' AND contrasenya='$contrasenya_cifrada'";
        $respuesta=mysqli_query($conexion,$consultarContrasenyaAntigua);
        // Si las filas affectadas es igual igual igual a 1 entonces devuelve true
        if (mysqli_affected_rows($conexion) === 1){
            return true;
        }
    }    
    function actualitzarcontrasenya($conexion,$consulta){    
        if(mysqli_query($conexion,$consulta)){  
            return true;        
        }else{
            return false;
        }
    }
    //Añadir nueva categoria
    function  nuevaCategoria($conexion,$nombreCategoria){
        if ($nombreCategoria<>""){
            $consultar="SELECT * FROM categorias WHERE nombre='$nombreCategoria'";
            $consultarExistencia=mysqli_query($conexion,$consultar);
            if (mysqli_affected_rows($conexion) === 0){
                    $insertar="INSERT INTO categorias VALUES (NULL, '$nombreCategoria')";
                    $insertarCategoria=mysqli_query($conexion,$insertar);
                    return true;
            }else {
                print "La categoria ya existe";
                return false;
            }
        }
    }
    function listarCategorias($conexion){
        $consulta="SELECT * FROM categorias";
        $filas=mysqli_query($conexion,$consulta);
        while ($fila=mysqli_fetch_array($filas)){
            $id=$fila["id_categoria"];
            $nombre=$fila["nombre"];
            $codigo .= '<tr>
            <th scope="row">' . $id . '</th>
            <td>' . $nombre . '</td>
            <td><a href="eliminarCategoria.php?id=' . $id . '">Eliminar</a></td>
        </tr> ';
        } 
        return $codigo;
    }
    function eliminarCategoria($conexion,$id){
        $eliminar="DELETE FROM categorias WHERE id_categoria='$id'";
        $eliminarCategoria=mysqli_query($conexion,$eliminar);
        if (mysqli_affected_rows($conexion) == 1){
            return true;
        }else {
            return false;
        }
    }
    // Primero creamos las creedenciales de los usuarios
    function consultarCreedencial($conexion,$cuenta){
        $consultar="SELECT * FROM creedenciales WHERE usuario='$cuenta'";
        $filas=mysqli_query($conexion,$consultar);
        if ($filas && mysqli_affected_rows($conexion) == 1){
            // Mostrar mensaje de actualización
            $_SESSION['mensaje'] = '<!--Contenido Pagina-->
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>ERROR </strong>La cuenta ' . $cuenta . ' ya existe en la bd por lo tanto no se ha creado ningun usuario
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';         
            return false;   
        }else {
            return true;
        }
    }
    function crearCreedencial($conexion,$insertarCreedenciales){
        if (mysqli_query($conexion,$insertarCreedenciales)){
            return true;
        }else{
            return false;
        } 
    }
    // En esta funcion vamos a saber en que id se ha creado la creedencial para relacionarla con el usuario
    function consultarId($conexion,$idCreedencial){
        $filas=mysqli_query($conexion,$idCreedencial);
        if ($filas && mysqli_affected_rows($conexion) == 1){
            while ($fila=mysqli_fetch_array($filas)){
                $id=$fila['id_login'];                            
            }
            return $id;
        }else{
            return false;            
        }      
    }
    function crearUsuario($conexion,$insertarUsuario){
        if (mysqli_query($conexion,$insertarUsuario)){
            return true;
        }else {            
            print "adios";
            #3return false;
        }
    }

?>